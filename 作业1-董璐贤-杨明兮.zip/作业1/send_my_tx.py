from bit import PrivateKeyTestnet

def send_test_tx():
    # 填入自己生成的私钥
    wif = "cN657accnJsX6hPvEXK7N881swuCj9U2jPrBwYAzQbnEDwNedabJ"
    my_key = PrivateKeyTestnet(wif)
    
    print(f"当前地址: {my_key.address}")
    balance = my_key.get_balance('satoshi')
    print(f"当前余额: {balance} 聪")
    
    target_address = PrivateKeyTestnet().address # 随机生成一个测试网目标地址
    
    try:
        # 转账 1000 聪
        tx_hash = my_key.send([(target_address, 1000, 'satoshi')])
        print(f"交易发送成功！TXID: {tx_hash}")
    except Exception as e:
        print(f"发送交易时出错: {e}")

if __name__ == "__main__":
    send_test_tx()
