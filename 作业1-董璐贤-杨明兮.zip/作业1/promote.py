import io
import struct
import urllib.request
import json


def to_bits(byte_data):
    """将十六进制字节转换为底层的 010101 二进制比特位 (Bits)"""
    return ' '.join(f'{b:08b}' for b in byte_data)


def read_varint(s):
    """逐字节读取可变整数，演示字节控制"""
    b = s.read(1)
    if not b: return 0, b''
    val = b[0]
    if val < 0xfd:
        return val, b
    elif val == 0xfd:
        data = s.read(2)
        return struct.unpack("<H", data)[0], b + data
    elif val == 0xfe:
        data = s.read(4)
        return struct.unpack("<I", data)[0], b + data
    else:
        data = s.read(8)
        return struct.unpack("<Q", data)[0], b + data


def disassemble_script(script_bytes):
    """脚本底层操作码反编译"""
    i = 0
    ops = []
    while i < len(script_bytes):
        op = script_bytes[i]
        i += 1
        if op == 0x00:
            ops.append("OP_0")
        elif 0x01 <= op <= 0x4b:
            push_len = op
            ops.append(f"PUSH_{push_len}[{script_bytes[i:i + push_len].hex()}]")
            i += push_len
        elif op == 0x76:
            ops.append("OP_DUP")
        elif op == 0xa9:
            ops.append("OP_HASH160")
        elif op == 0x88:
            ops.append("OP_EQUALVERIFY")
        elif op == 0xac:
            ops.append("OP_CHECKSIG")
        else:
            ops.append(f"OP_0x{op:02x}")
    return " ".join(ops)


def parse_tx(s, tx_index="Standalone"):
    """
    流式解析单笔交易。不仅输出 Hex，还输出二进制 Bits。
    s 必须是 BytesIO 对象，这样在解析完整区块时可以连续不断地往下读。
    """
    print(f"\n{'=' * 50}")
    print(f" 正在逐比特解析交易 [TX Index: {tx_index}]")
    print(f"{'=' * 50}")

    # 1. 解析 Version
    version = s.read(4)
    print(f"[Version]\n  Hex: {version.hex()}\n  Bits: {to_bits(version)} \n  Int: {struct.unpack('<I', version)[0]}")

    # 2. 判断 Segwit 标记
    pos = s.tell()
    marker_flag = s.read(2)
    is_segwit = False
    if marker_flag == b'\x00\x01':
        is_segwit = True
        print(f"\n[SegWit Marker]\n  Hex: {marker_flag.hex()}\n  Bits: {to_bits(marker_flag)}  <-- 识别为隔离见证交易!")
    else:
        s.seek(pos)  # 如果不是隔离见证，游标退回去

    # 3. 解析 Inputs
    in_count, in_count_raw = read_varint(s)
    print(f"\n[Input Count]\n  Bits: {to_bits(in_count_raw)} -> {in_count} 个输入")

    for i in range(in_count):
        print(f"  --- Input {i} ---")
        prev_tx = s.read(32)
        print(f"  [Prev TXID] Hex: {prev_tx[::-1].hex()}")
        vout = s.read(4)
        print(f"  [Prev VOUT] Bits: {to_bits(vout)} | Index: {struct.unpack('<I', vout)[0]}")
        script_len, _ = read_varint(s)
        script_sig = s.read(script_len)
        if script_len > 0:
            print(f"  [ 解锁脚本反编译]: {disassemble_script(script_sig)}")
        seq = s.read(4)
        print(f"  [Sequence] Bits: {to_bits(seq)}")

    # 4. 解析 Outputs
    out_count, out_count_raw = read_varint(s)
    print(f"\n[Output Count]\n  Bits: {to_bits(out_count_raw)} -> {out_count} 个输出")

    for i in range(out_count):
        print(f"  --- Output {i} ---")
        val = s.read(8)
        print(f"  [Value] Bits: {to_bits(val)} | 金额: {struct.unpack('<q', val)[0]} 聪")
        script_len, _ = read_varint(s)
        script_pubkey = s.read(script_len)
        print(f"  [锁定脚本反编译]: {disassemble_script(script_pubkey)}")

    # 5. 解析 Witness Data
    if is_segwit:
        print("\n[Witness Data 解析中...]")
        for i in range(in_count):
            wit_count, _ = read_varint(s)
            for j in range(wit_count):
                item_len, _ = read_varint(s)
                item = s.read(item_len)

    # 6. 解析 LockTime
    locktime = s.read(4)
    print(f"\n[LockTime]\n  Hex: {locktime.hex()}\n  Bits: {to_bits(locktime)}")


def parse_whole_block(hex_data):
    """【硬核要求满足】：遍历解析完整的区块（Block Header + 全部 Transactions）"""
    s = io.BytesIO(bytes.fromhex(hex_data))
    print("\n\n" + "#" * 60)
    print("  开始遍历解析完整区块 (WHOLE BLOCK PARSER)")
    print("#" * 60)

    print("\n>>> 第一部分：解析 80 字节区块头 (Block Header) <<<")
    version = s.read(4)
    print(f"[Version] Bits: {to_bits(version)}")
    prev_block = s.read(32)
    print(f"[PrevBlock] Hex: {prev_block[::-1].hex()}")
    merkle = s.read(32)
    print(f"[MerkleRoot] Hex: {merkle[::-1].hex()}")
    time_ = s.read(4)
    print(f"[Timestamp] Bits: {to_bits(time_)} -> {struct.unpack('<I', time_)[0]}")
    bits = s.read(4)
    print(f"[Bits] Bits: {to_bits(bits)}")
    nonce = s.read(4)
    print(f"[Nonce] Bits: {to_bits(nonce)} -> Int: {struct.unpack('<I', nonce)[0]}")

    print("\n>>> 第二部分：开始逐字节解析区块内包含的每一笔交易 <<<")
    tx_count, tx_count_raw = read_varint(s)
    print(f"[本区块交易总数] Bits: {to_bits(tx_count_raw)} -> 共 {tx_count} 笔交易！")

    # 核心：循环解析区块里的所有交易！
    for i in range(tx_count):
        parse_tx(s, tx_index=i)

    print("\n 完整区块遍历解析结束！")


if __name__ == '__main__':
    txid = '395a637b65c0bbad030469d7063f71e48805a45ed94b56c11edc2e2effce6a7f'

    print("1. 正在通过网络动态抓取交易的完整二进制数据...")
    req = urllib.request.Request(f'https://blockstream.info/testnet/api/tx/{txid}/hex')
    tx_hex = urllib.request.urlopen(req).read().decode('utf-8')
    # 流式解析单独一笔交易
    parse_tx(io.BytesIO(bytes.fromhex(tx_hex)))

    print("\n2. 正在通过网络动态抓取所在的【完整区块】二进制数据...")
    # 获取区块哈希
    req_tx = urllib.request.Request(f'https://blockstream.info/testnet/api/tx/{txid}')
    tx_info = json.loads(urllib.request.urlopen(req_tx).read().decode('utf-8'))
    block_hash = tx_info['status']['block_hash']

    # 抓取包含所有交易的完整区块原始数据！
    req_blk = urllib.request.Request(f'https://blockstream.info/testnet/api/block/{block_hash}/raw')
    block_raw = urllib.request.urlopen(req_blk).read()

    # 解析整个区块！
    parse_whole_block(block_raw.hex())