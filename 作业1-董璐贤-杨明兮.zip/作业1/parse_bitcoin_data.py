import io
import struct


def read_varint(s):
    """读取比特币的可变长度整数 (VarInt)"""
    b = s.read(1)
    if not b: return 0, b''
    val = b[0]
    if val < 0xfd:
        return val, b
    elif val == 0xfd:
        return struct.unpack("<H", s.read(2))[0], b + s.read(2)
    elif val == 0xfe:
        return struct.unpack("<I", s.read(4))[0], b + s.read(4)
    else:
        return struct.unpack("<Q", s.read(8))[0], b + s.read(8)


def disassemble_script(script_bytes):
    """将锁定脚本还原为底层 OP_CODE 汇编指令"""
    i = 0
    ops = []
    while i < len(script_bytes):
        op = script_bytes[i]
        i += 1
        if op == 0x00:
            ops.append("OP_0")
        elif 0x01 <= op <= 0x4b:
            push_len = op
            ops.append(f"PUSH_{push_len}[{script_bytes[i:i + push_len].hex()}]")
            i += push_len
        elif op == 0x76:
            ops.append("OP_DUP")
        elif op == 0xa9:
            ops.append("OP_HASH160")
        elif op == 0x88:
            ops.append("OP_EQUALVERIFY")
        elif op == 0xac:
            ops.append("OP_CHECKSIG")
        else:
            ops.append(f"OP_0x{op:02x}")
    return " ".join(ops)


def parse_tx(hex_data):
    """交易逐字节解析"""
    s = io.BytesIO(bytes.fromhex(hex_data))
    print("========================================")
    print("       BITCOIN TX PARSER (TESTNET)      ")
    print("========================================\n")

    print(f"[Version]: {s.read(4).hex()} -> Little Endian: 1")
    in_count, _ = read_varint(s)
    print(f"\n[Input Count]: {in_count} input(s)")

    for i in range(in_count):
        print(f"  --- Input {i} ---")
        print(f"  [Previous TXID]: {s.read(32)[::-1].hex()}")
        print(f"  [Previous VOUT]: Index {struct.unpack('<I', s.read(4))[0]}")
        script_len, _ = read_varint(s)
        script_sig = s.read(script_len)
        print(f"  [ScriptSig Length]: {script_len} bytes")
        if script_len > 0:
            print(f"  [解锁脚本反编译 OP_CODE]: {disassemble_script(script_sig)}")
        print(f"  [Sequence]: {s.read(4).hex()}")

    out_count, _ = read_varint(s)
    print(f"\n[Output Count]: {out_count} output(s)")
    for i in range(out_count):
        print(f"  --- Output {i} ---")
        value = s.read(8)
        print(f"  [Value]: {struct.unpack('<q', value)[0]} Satoshis")
        script_len, _ = read_varint(s)
        script_pubkey = s.read(script_len)
        print(f"  [ScriptPubKey Length]: {script_len} bytes")
        print(f"  [ 锁定脚本反编译 OP_CODE]: {disassemble_script(script_pubkey)}")

    print(f"\n[LockTime]: {s.read(4).hex()}")


def parse_block_header(hex_data):
    """区块头逐字节解析"""
    s = io.BytesIO(bytes.fromhex(hex_data))
    print("\n========================================")
    print("      BITCOIN BLOCK HEADER PARSER       ")
    print("========================================\n")
    print(f"[Version]: {s.read(4).hex()}")
    print(f"[Previous Block Hash]: {s.read(32)[::-1].hex()}")
    print(f"[Merkle Root]: {s.read(32)[::-1].hex()}")
    print(f"[Timestamp]: {struct.unpack('<I', s.read(4))[0]} (Unix Time)")
    print(f"[Difficulty Target (Bits)]: {s.read(4).hex()}")
    print(f"[Nonce]: {struct.unpack('<I', s.read(4))[0]}")
    tx_count, _ = read_varint(s)
    print(f"\n[Transaction Count]: {tx_count} transaction(s) follow in the block")


if __name__ == '__main__':
    # 成功发送的真实交易数据
    my_tx = '0100000001c6961454f95ac50a93c2714987e772f667b3d543ead89418f6bcb77a192702b6010000006a47304402205332de9459890bcd18e0e251c918e6a952dca4f2df5d9b629a2cb9953064d14f022038ad6bda1c2a1cb4751f5b2cd0ced80d8c53a2d6fa7d2171686a27a5b638bccc012102f6340398e935e6e737ad56d1b124b5c540b2d0dfe2f3dd1b6951892d989999deffffffff02e8030000000000001976a914f613e51cfc9715b6dfb13b7334140fbbc726daa288ac6a430200000000001976a9147ba20fdf9f7e7e1b3ac605ed013717b90269221c88ac00000000'
    # 测试网的真实区块头数据
    my_block = '00000020917da6576d654f650becd4fb44e31a2490e0a3e311f718b70d074b1600000000a9394d8039835ce4e4a9cd1371b556ef577e60a5735633444b31e020d30bd30472065e6affff001dc59ac214'
    parse_tx(my_tx)
    parse_block_header(my_block)