import urllib.request
import json

def fetch_and_parse_block():
    print("==================================================")
    print("🧱 比特币测试网最新区块解析")
    print("==================================================")
    
    req = urllib.request.Request('https://blockstream.info/testnet/api/blocks/tip/hash')
    with urllib.request.urlopen(req) as response:
        block_hash = response.read().decode('utf-8').strip()
        
    print(f"[最新区块哈希 Block Hash]: {block_hash}")
    
    req = urllib.request.Request(f'https://blockstream.info/testnet/api/block/{block_hash}')
    with urllib.request.urlopen(req) as response:
        block_data = json.loads(response.read().decode('utf-8'))
        
    print(f"[区块高度 Height]: {block_data['height']}")
    print(f"[版本号 Version]: {block_data['version']}")
    print(f"[前置区块哈希 Previous Block]: {block_data['previousblockhash']}")
    print(f"[默克尔根 Merkle Root]: {block_data['merkle_root']}")
    print(f"[时间戳 Timestamp]: {block_data['timestamp']}")
    print(f"[随机数 Nonce]: {block_data['nonce']}")
    print(f"[难度目标 Bits]: {block_data['bits']}")
    print(f"[包含交易总数 TX Count]: {block_data['tx_count']} 笔交易")
    print("==================================================")

if __name__ == '__main__':
    fetch_and_parse_block()
