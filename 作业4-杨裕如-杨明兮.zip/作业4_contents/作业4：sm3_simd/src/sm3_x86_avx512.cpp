#if defined(__x86_64__) || defined(_M_X64)
#include <immintrin.h>
#include "sm3_common.hpp"
#include "../include/sm3.hpp"

namespace sm3 {

    void compress_avx512(std::array<uint32_t, 8>& state,
        const uint8_t* data,
        std::size_t num_blocks)
    {
#ifdef __AVX512F__
        const __m512i bswap = _mm512_set_epi8(
            60, 61, 62, 63, 56, 57, 58, 59, 52, 53, 54, 55, 48, 49, 50, 51,
            44, 45, 46, 47, 40, 41, 42, 43, 36, 37, 38, 39, 32, 33, 34, 35,
            28, 29, 30, 31, 24, 25, 26, 27, 20, 21, 22, 23, 16, 17, 18, 19,
            12, 13, 14, 15, 8, 9, 10, 11, 4, 5, 6, 7, 0, 1, 2, 3);

        while (num_blocks--) {
            uint32_t W[68], Wp[64];

            // W[0..15] һ��512-bit����
            __m512i v = _mm512_loadu_si512((const __m512i*)data);
            _mm512_storeu_si512((__m512i*)W,
                _mm512_shuffle_epi8(v, bswap));

            // W[16..67] ��������
            for (int j = 16; j < 68; ++j) {
                uint32_t tmp = W[j - 16] ^ W[j - 9] ^ detail::rotl32(W[j - 3], 15);
                W[j] = detail::P1(tmp) ^ detail::rotl32(W[j - 13], 7) ^ W[j - 6];
            }

            // W'[0..63] 4x 512-bit XOR
            for (int j = 0; j < 64; j += 16) {
                __m512i a = _mm512_loadu_si512((const __m512i*)(W + j));
                __m512i b = _mm512_loadu_si512((const __m512i*)(W + j + 4));
                _mm512_storeu_si512((__m512i*)(Wp + j),
                    _mm512_xor_si512(a, b));
            }

            detail::compress_rounds(state, W, Wp);
            data += BLOCK_SIZE;
        }
#else
        // û�� AVX512 ���˵� AVX2
        compress_avx2(state, data, num_blocks);
#endif
    }

} // namespace sm3
#endif