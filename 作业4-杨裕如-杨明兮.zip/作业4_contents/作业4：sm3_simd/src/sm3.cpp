#include <atomic>
#include <cstring>

#if defined(__x86_64__) || defined(_M_X64)
#  ifdef _MSC_VER
#    include <intrin.h>
#  else
#    include <cpuid.h>
#  endif
#endif

#include "sm3_common.hpp"
#include "../include/sm3.hpp"

namespace sm3 {

    // ------------------------------------------------------------------ //
    // CPU ���Լ��
    // ------------------------------------------------------------------ //

#if defined(__x86_64__) || defined(_M_X64)

    static void do_cpuid(int info[4], int leaf, int subleaf = 0) noexcept
    {
#ifdef _MSC_VER
        __cpuidex(info, leaf, subleaf);
#else
        __cpuid_count(leaf, subleaf,
            info[0], info[1], info[2], info[3]);
#endif
    }

    static bool cpu_has_avx2() noexcept
    {
        int info[4];
        do_cpuid(info, 0);
        if (info[0] < 7) return false;
        do_cpuid(info, 7, 0);
        return (info[1] & (1 << 5)) != 0;
    }

    static bool cpu_has_avx512() noexcept
    {
        int info[4];
        do_cpuid(info, 0);
        if (info[0] < 7) return false;
        do_cpuid(info, 7, 0);
        return (info[1] & (1 << 16)) != 0;
    }

#endif

    // ------------------------------------------------------------------ //
    // ȫ��ʵ��ѡ��
    // ------------------------------------------------------------------ //

    static std::atomic<Impl> g_impl{ Impl::Auto };

    Impl best_impl() noexcept
    {
#if defined(__x86_64__) || defined(_M_X64)
        if (cpu_has_avx512()) return Impl::AVX512;
        if (cpu_has_avx2())   return Impl::AVX2;
#elif defined(__aarch64__)
        return Impl::ARM64;
#endif
        return Impl::Ref;
    }

    void set_impl(Impl impl) noexcept
    {
        g_impl.store(impl, std::memory_order_relaxed);
    }

    Impl get_impl() noexcept
    {
        return g_impl.load(std::memory_order_relaxed);
    }

    std::string_view impl_name(Impl impl) noexcept
    {
        switch (impl) {
        case Impl::Ref:    return "Reference (scalar)";
        case Impl::AVX2:   return "x86-64 AVX2";
        case Impl::AVX512: return "x86-64 AVX-512";
        case Impl::ARM64:  return "ARM64 NEON";
        case Impl::Auto:   return "Auto";
        default:           return "Unknown";
        }
    }

    static CompressFn resolve_compress(Impl impl) noexcept
    {
        if (impl == Impl::Auto) impl = best_impl();
        switch (impl) {
#if defined(__x86_64__) || defined(_M_X64)
        case Impl::AVX2:   return compress_avx2;
        case Impl::AVX512: return compress_avx512;
#endif
#if defined(__aarch64__)
        case Impl::ARM64:  return compress_arm64;
#endif
        default:           return compress_ref;
        }
    }

    // ------------------------------------------------------------------ //
    // Context
    // ------------------------------------------------------------------ //

    Context::Context(Impl impl)
        : state_(detail::IV)
        , count_(0)
        , buf_{}
        , buf_len_(0)
        , compress_(resolve_compress(impl))
    {
    }

    void Context::reset()
    {
        state_ = detail::IV;
        count_ = 0;
        buf_len_ = 0;
        buf_.fill(0);
    }

    void Context::update(const void* data, std::size_t len)
    {
        const uint8_t* ptr = static_cast<const uint8_t*>(data);

        if (len == 0) return;

        count_ += static_cast<uint64_t>(len) * 8;

        // ������������
        if (buf_len_ > 0) {
            uint32_t need = BLOCK_SIZE - buf_len_;
            if (len < need) {
                std::memcpy(buf_.data() + buf_len_, ptr, len);
                buf_len_ += static_cast<uint32_t>(len);
                return;
            }
            std::memcpy(buf_.data() + buf_len_, ptr, need);
            compress_(state_, buf_.data(), 1);
            ptr += need;
            len -= need;
            buf_len_ = 0;
        }

        // ����ֱ��ѹ��
        if (len >= BLOCK_SIZE) {
            std::size_t full_blocks = len / BLOCK_SIZE;
            compress_(state_, ptr, full_blocks);
            ptr += full_blocks * BLOCK_SIZE;
            len -= full_blocks * BLOCK_SIZE;
        }

        // ʣ��Ż�����
        if (len > 0) {
            std::memcpy(buf_.data(), ptr, len);
            buf_len_ = static_cast<uint32_t>(len);
        }
    }

    Digest Context::final()
    {
        buf_[buf_len_++] = 0x80;

        if (buf_len_ > 56) {
            std::memset(buf_.data() + buf_len_, 0, BLOCK_SIZE - buf_len_);
            compress_(state_, buf_.data(), 1);
            buf_len_ = 0;
        }

        std::memset(buf_.data() + buf_len_, 0, 56 - buf_len_);
        detail::store_be64(buf_.data() + 56, count_);
        compress_(state_, buf_.data(), 1);

        Digest out{};
        for (int i = 0; i < 8; i++)
            detail::store_be32(out.data() + i * 4, state_[i]);
        return out;
    }

    Digest Context::hash(const void* data, std::size_t len, Impl impl)
    {
        Context ctx(impl);
        ctx.update(data, len);
        return ctx.final();
    }

    Digest Context::hash(std::string_view str, Impl impl)
    {
        return hash(str.data(), str.size(), impl);
    }

    // ------------------------------------------------------------------ //
    // to_hex
    // ------------------------------------------------------------------ //

    std::string to_hex(const Digest& d)
    {
        static constexpr char HEX[] = "0123456789abcdef";
        std::string out(64, '0');
        for (int i = 0; i < 32; i++) {
            out[i * 2] = HEX[(d[i] >> 4) & 0xf];
            out[i * 2 + 1] = HEX[d[i] & 0xf];
        }
        return out;
    }

} // namespace sm3