#if defined(__aarch64__)
#include <arm_neon.h>
#include "sm3_common.hpp"
#include "../include/sm3.hpp"

namespace sm3::arm64 {

    static void msg_expand(const uint8_t* block,
        uint32_t W[68], uint32_t Wp[64]) noexcept
    {
        // W[0..15]: NEON ���ת����4��һ��
        for (int i = 0; i < 4; ++i) {
            uint8x16_t raw = vld1q_u8(block + i * 16);
            uint8x16_t swapped = vrev32q_u8(raw);
            vst1q_u32(W + i * 4, vreinterpretq_u32_u8(swapped));
        }

        // W[16..67] ��������
        for (int j = 16; j < 68; ++j) {
            uint32_t tmp = W[j - 16] ^ W[j - 9] ^ detail::rotl32(W[j - 3], 15);
            W[j] = detail::P1(tmp) ^ detail::rotl32(W[j - 13], 7) ^ W[j - 6];
        }

        // W'[0..63]: NEON XOR��4��һ��
        for (int j = 0; j < 64; j += 4) {
            uint32x4_t a = vld1q_u32(W + j);
            uint32x4_t b = vld1q_u32(W + j + 4);
            vst1q_u32(Wp + j, veorq_u32(a, b));
        }
    }

    static void compress_block(std::array<uint32_t, 8>& state,
        const uint8_t* block) noexcept
    {
        alignas(16) uint32_t W[68], Wp[64];
        msg_expand(block, W, Wp);
        detail::compress_rounds(state, W, Wp);
    }

} // namespace sm3::arm64

namespace sm3 {
    void compress_arm64(std::array<uint32_t, 8>& state,
        const uint8_t* data, std::size_t num_blocks)
    {
        while (num_blocks--) {
            arm64::compress_block(state, data);
            data += BLOCK_SIZE;
        }
    }
} // namespace sm3

#endif // __aarch64__