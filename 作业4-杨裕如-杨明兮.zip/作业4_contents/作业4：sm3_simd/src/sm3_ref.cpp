#include "sm3_common.hpp"
#include "../include/sm3.hpp"

namespace sm3 {

    void compress_ref(std::array<uint32_t, 8>& state,
        const uint8_t* data,
        std::size_t num_blocks)
    {
        uint32_t W[68], Wp[64];
        while (num_blocks--) {
            detail::msg_expand_scalar(data, W, Wp);
            detail::compress_rounds(state, W, Wp);
            data += BLOCK_SIZE;
        }
    }

} // namespace sm3