#pragma once

#include <array>
#include <cstdint>
#include <cstring>

// MSVC ����ͷ�ļ�
#ifdef _MSC_VER
#  include <intrin.h>
#  include <stdlib.h>
#endif

namespace sm3::detail {

    // ------------------------------------------------------------------ //
    // �ֽ�����
    // ------------------------------------------------------------------ //

    inline bool is_little_endian() noexcept
    {
        uint32_t x = 1;
        return *reinterpret_cast<uint8_t*>(&x) == 1;
    }

    // ------------------------------------------------------------------ //
    // ������� bswap
    // ------------------------------------------------------------------ //

    inline uint32_t bswap32(uint32_t x) noexcept
    {
#ifdef _MSC_VER
        return _byteswap_ulong(x);
#else
        return __builtin_bswap32(x);
#endif
    }

    inline uint64_t bswap64(uint64_t x) noexcept
    {
#ifdef _MSC_VER
        return _byteswap_uint64(x);
#else
        return __builtin_bswap64(x);
#endif
    }

    // ------------------------------------------------------------------ //
    // ������� forceinline
    // ------------------------------------------------------------------ //

#ifdef _MSC_VER
#  define SM3_FORCEINLINE __forceinline
#else
#  define SM3_FORCEINLINE __attribute__((always_inline)) inline
#endif

// ------------------------------------------------------------------ //
// �������ѭ������
// ------------------------------------------------------------------ //

    inline uint32_t rotl32(uint32_t x, int n) noexcept
    {
#ifdef _MSC_VER
        return _rotl(x, n);
#else
        return (x << n) | (x >> (32 - n));
#endif
    }

    // ------------------------------------------------------------------ //
    // IV
    // ------------------------------------------------------------------ //

    inline constexpr std::array<uint32_t, 8> IV = {
        0x7380166fU, 0x4914b2b9U, 0x172442d7U, 0xda8a0600U,
        0xa96f30bcU, 0x163138aaU, 0xe38dee4dU, 0xb0fb0e4eU,
    };

    // ------------------------------------------------------------------ //
    // Tj ��������ֱ��չ�������� MSVC constexpr lambda ���⣩
    // T0 = 0x79cc4519, rotl(T0, j) for j=0..15
    // T1 = 0x7a879d8a, rotl(T1, j%32) for j=16..63
    // ------------------------------------------------------------------ //

    inline constexpr uint32_t Tj[64] = {
        // j = 0..15
        0x79cc4519u, 0xf3988a32u, 0xe7311465u, 0xce6228cbu,
        0x9cc45197u, 0x3988a32fu, 0x7311465eu, 0xe6228cbcu,
        0xcc451979u, 0x988a32f3u, 0x311465e7u, 0x6228cbceu,
        0xc451979cu, 0x88a32f39u, 0x11465e73u, 0x228cbce6u,
        // j = 16..31
        0x9d8a7a87u, 0x3b14f50fu, 0x7629ea1eu, 0xec53d43cu,
        0xd8a7a879u, 0xb14f50f3u, 0x629ea1e7u, 0xc53d43ceu,
        0x8a7a879du, 0x14f50f3bu, 0x29ea1e76u, 0x53d43cecu,
        0xa7a879d8u, 0x4f50f3b1u, 0x9ea1e762u, 0x3d43cec5u,
        // j = 32..47
        0x7a879d8au, 0xf50f3b14u, 0xea1e7629u, 0xd43cec53u,
        0xa879d8a7u, 0x50f3b14fu, 0xa1e7629eu, 0x43cec53du,
        0x879d8a7au, 0x0f3b14f5u, 0x1e7629eau, 0x3cec53d4u,
        0x79d8a7a8u, 0xf3b14f50u, 0xe7629ea1u, 0xcec53d43u,
        // j = 48..63
        0x9d8a7a87u, 0x3b14f50fu, 0x7629ea1eu, 0xec53d43cu,
        0xd8a7a879u, 0xb14f50f3u, 0x629ea1e7u, 0xc53d43ceu,
        0x8a7a879du, 0x14f50f3bu, 0x29ea1e76u, 0x53d43cecu,
        0xa7a879d8u, 0x4f50f3b1u, 0x9ea1e762u, 0x3d43cec5u,
    };

    // ------------------------------------------------------------------ //
    // SM3 ��������
    // ------------------------------------------------------------------ //

    inline uint32_t P0(uint32_t x) noexcept
    {
        return x ^ rotl32(x, 9) ^ rotl32(x, 17);
    }

    inline uint32_t P1(uint32_t x) noexcept
    {
        return x ^ rotl32(x, 15) ^ rotl32(x, 23);
    }

    inline uint32_t FF(uint32_t x, uint32_t y, uint32_t z, int j) noexcept
    {
        return (j < 16) ? (x ^ y ^ z)
            : ((x & y) | ((x | y) & z));
    }

    inline uint32_t GG(uint32_t x, uint32_t y, uint32_t z, int j) noexcept
    {
        return (j < 16) ? (x ^ y ^ z)
            : ((x & y) | (~x & z));
    }

    // ------------------------------------------------------------------ //
    // �ֽ����д
    // ------------------------------------------------------------------ //

    inline uint32_t load_be32(const uint8_t* p) noexcept
    {
        uint32_t v;
        std::memcpy(&v, p, 4);
        if (is_little_endian()) v = bswap32(v);
        return v;
    }

    inline void store_be32(uint8_t* p, uint32_t x) noexcept
    {
        if (is_little_endian()) x = bswap32(x);
        std::memcpy(p, &x, 4);
    }

    inline void store_be64(uint8_t* p, uint64_t x) noexcept
    {
        if (is_little_endian()) x = bswap64(x);
        std::memcpy(p, &x, 8);
    }

    // ------------------------------------------------------------------ //
    // ��Ϣ��չ��������
    // ------------------------------------------------------------------ //

    inline void msg_expand_scalar(const uint8_t* block,
        uint32_t W[68],
        uint32_t Wp[64]) noexcept
    {
        for (int j = 0; j < 16; j++)
            W[j] = load_be32(block + j * 4);

        for (int j = 16; j < 68; j++) {
            uint32_t tmp = W[j - 16] ^ W[j - 9] ^ rotl32(W[j - 3], 15);
            W[j] = P1(tmp) ^ rotl32(W[j - 13], 7) ^ W[j - 6];
        }

        for (int j = 0; j < 64; j++)
            Wp[j] = W[j] ^ W[j + 4];
    }

    // ------------------------------------------------------------------ //
    // ѹ���ֺ���
    // ------------------------------------------------------------------ //

    inline void compress_rounds(std::array<uint32_t, 8>& S,
        const uint32_t W[68],
        const uint32_t Wp[64]) noexcept
    {
        uint32_t A = S[0], B = S[1], C = S[2], D = S[3];
        uint32_t E = S[4], F = S[5], G = S[6], H = S[7];

        for (int j = 0; j < 64; j++) {
            uint32_t SS1 = rotl32(rotl32(A, 12) + E + Tj[j], 7);
            uint32_t SS2 = SS1 ^ rotl32(A, 12);
            uint32_t TT1 = FF(A, B, C, j) + D + SS2 + Wp[j];
            uint32_t TT2 = GG(E, F, G, j) + H + SS1 + W[j];
            D = C;
            C = rotl32(B, 9);
            B = A;
            A = TT1;
            H = G;
            G = rotl32(F, 19);
            F = E;
            E = P0(TT2);
        }

        S[0] ^= A; S[1] ^= B; S[2] ^= C; S[3] ^= D;
        S[4] ^= E; S[5] ^= F; S[6] ^= G; S[7] ^= H;
    }

} // namespace sm3::detail