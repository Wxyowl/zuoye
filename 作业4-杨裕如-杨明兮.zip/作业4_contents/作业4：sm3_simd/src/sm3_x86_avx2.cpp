#if defined(__x86_64__) || defined(_M_X64)
#include <immintrin.h>
#include "sm3_common.hpp"
#include "../include/sm3.hpp"

namespace sm3 {

    void compress_avx2(std::array<uint32_t, 8>& state,
        const uint8_t* data,
        std::size_t num_blocks)
    {
        // AVX2��W[0..15] bswap �� _mm256_shuffle_epi8��W' �� 256-bit XOR
        const __m256i bswap = _mm256_set_epi8(
            28, 29, 30, 31, 24, 25, 26, 27, 20, 21, 22, 23, 16, 17, 18, 19,
            12, 13, 14, 15, 8, 9, 10, 11, 4, 5, 6, 7, 0, 1, 2, 3);

        while (num_blocks--) {
            uint32_t W[68], Wp[64];

            // W[0..7]
            __m256i v0 = _mm256_loadu_si256((const __m256i*)(data));
            _mm256_storeu_si256((__m256i*)W,
                _mm256_shuffle_epi8(v0, bswap));
            // W[8..15]
            __m256i v1 = _mm256_loadu_si256((const __m256i*)(data + 32));
            _mm256_storeu_si256((__m256i*)(W + 8),
                _mm256_shuffle_epi8(v1, bswap));

            // W[16..67] ��������
            for (int j = 16; j < 68; ++j) {
                uint32_t tmp = W[j - 16] ^ W[j - 9] ^ detail::rotl32(W[j - 3], 15);
                W[j] = detail::P1(tmp) ^ detail::rotl32(W[j - 13], 7) ^ W[j - 6];
            }

            // W'[0..63] 8��һ��
            for (int j = 0; j < 64; j += 8) {
                __m256i a = _mm256_loadu_si256((const __m256i*)(W + j));
                __m256i b = _mm256_loadu_si256((const __m256i*)(W + j + 4));
                _mm256_storeu_si256((__m256i*)(Wp + j),
                    _mm256_xor_si256(a, b));
            }

            detail::compress_rounds(state, W, Wp);
            data += BLOCK_SIZE;
        }
    }

} // namespace sm3
#endif