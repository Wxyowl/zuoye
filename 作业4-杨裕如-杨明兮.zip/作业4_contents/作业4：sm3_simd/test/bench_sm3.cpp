#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "../include/sm3.hpp"

using Clock = std::chrono::high_resolution_clock;
using Dur = std::chrono::duration<double>;

// ------------------------------------------------------------------ //
// ��׼���
// ------------------------------------------------------------------ //

struct BenchResult {
    double throughput_mbps;
    double latency_us;
};

// ------------------------------------------------------------------ //
// ���λ�׼����
// ------------------------------------------------------------------ //

static BenchResult bench_impl(sm3::Impl impl,
    std::size_t data_size,
    int iterations)
{
    std::vector<uint8_t> data(data_size, 0x61);
    sm3::Digest sink{};

    // Ԥ�� 3 ��
    for (int i = 0; i < 3; i++)
        sink = sm3::hash(data.data(), data.size(), impl);

    // ��ʽ��ʱ
    auto t0 = Clock::now();
    for (int i = 0; i < iterations; i++) {
        auto d = sm3::hash(data.data(), data.size(), impl);
        sink[0] ^= d[0];
    }
    auto t1 = Clock::now();

    // ��ֹ sink ���Ż���
    if (sink[0] == 0xff && sink[1] == 0xff)
        std::cout << "(sink)\n";

    double elapsed_s = Dur(t1 - t0).count();
    double total_mb = static_cast<double>(data_size) * iterations
        / (1024.0 * 1024.0);

    return {
        total_mb / elapsed_s,
        elapsed_s / iterations * 1e6
    };
}

// ------------------------------------------------------------------ //
// ��ӡ����
// ------------------------------------------------------------------ //

static void print_header()
{
    std::cout << std::left
        << std::setw(20) << "Implementation"
        << std::setw(12) << "DataSize"
        << std::setw(16) << "Throughput"
        << std::setw(14) << "Latency"
        << "\n"
        << std::string(62, '-') << "\n";
}

static void print_row(std::string_view name,
    std::size_t data_size,
    const BenchResult& r)
{
    std::string size_str;
    if (data_size >= 1024 * 1024)
        size_str = std::to_string(data_size / (1024 * 1024)) + " MB";
    else if (data_size >= 1024)
        size_str = std::to_string(data_size / 1024) + " KB";
    else
        size_str = std::to_string(data_size) + " B";

    std::ostringstream tp_ss, lat_ss;
    tp_ss << static_cast<int>(r.throughput_mbps) << " MB/s";
    lat_ss << std::fixed << std::setprecision(2) << r.latency_us << " us";

    std::cout << std::left
        << std::setw(20) << name
        << std::setw(12) << size_str
        << std::setw(16) << tp_ss.str()
        << std::setw(14) << lat_ss.str()
        << "\n";
}

// ------------------------------------------------------------------ //
// �Ե���ʵ�����������ݹ�ģ
// ------------------------------------------------------------------ //

static void bench_all_sizes(sm3::Impl impl, std::string_view name)
{
    struct {
        std::size_t size;
        int         iters;
    } cases[] = {
        {       16,  500000 },
        {       64,  500000 },
        {      256,  200000 },
        {     1024,   50000 },
        {     4096,   20000 },
        {    65536,    2000 },
        {  1048576,     200 },
    };

    print_header();
    for (auto& c : cases)
        print_row(name, c.size, bench_impl(impl, c.size, c.iters));
    std::cout << "\n";
}

// ------------------------------------------------------------------ //
// �����������Աȣ��̶� 4KB��
// ------------------------------------------------------------------ //

static void bench_comparison()
{
    constexpr std::size_t SIZE = 4096;
    constexpr int         ITERS = 20000;

    std::cout << "=== Throughput Comparison (data=" << SIZE << " B, "
        << ITERS << " iters) ===\n"
        << std::string(62, '-') << "\n";

    double ref_tp = 0.0;

    auto run_one = [&](sm3::Impl impl,
        const char* name,
        bool available)
        {
            if (!available) {
                std::cout << std::left << std::setw(20) << name
                    << "[not available on this CPU]\n";
                return;
            }

            auto r = bench_impl(impl, SIZE, ITERS);

            if (impl == sm3::Impl::Ref)
                ref_tp = r.throughput_mbps;

            double speedup = (ref_tp > 0.0) ? r.throughput_mbps / ref_tp : 1.0;

            std::ostringstream tp_ss;
            tp_ss << static_cast<int>(r.throughput_mbps) << " MB/s";

            std::cout << std::left
                << std::setw(20) << name
                << std::setw(16) << tp_ss.str()
                << "speedup: x" << std::fixed << std::setprecision(2)
                << speedup << "\n";
        };

    run_one(sm3::Impl::Ref, "Ref (scalar)", true);

#if defined(__x86_64__) || defined(_M_X64)
    bool has_avx2 = (sm3::best_impl() >= sm3::Impl::AVX2);
    bool has_avx512 = (sm3::best_impl() == sm3::Impl::AVX512);
    run_one(sm3::Impl::AVX2, "AVX2", has_avx2);
    run_one(sm3::Impl::AVX512, "AVX-512", has_avx512);
#endif

#if defined(__aarch64__)
    run_one(sm3::Impl::ARM64, "ARM64 NEON", true);
#endif

    std::cout << "\n";
}

// ------------------------------------------------------------------ //
// main
// ------------------------------------------------------------------ //

int main()
{
    std::cout << "============================================\n"
        << "  SM3 Benchmark\n"
        << "  Best impl: " << sm3::impl_name(sm3::best_impl()) << "\n"
        << "============================================\n\n";

    // �ο�ʵ��
    std::cout << "=== Reference (scalar) ===\n";
    bench_all_sizes(sm3::Impl::Ref, "Ref");

#if defined(__x86_64__) || defined(_M_X64)
    // AVX2
    std::cout << "=== AVX2 ===\n";
    bench_all_sizes(sm3::Impl::AVX2, "AVX2");

    // AVX512
    if (sm3::best_impl() == sm3::Impl::AVX512) {
        std::cout << "=== AVX-512 ===\n";
        bench_all_sizes(sm3::Impl::AVX512, "AVX512");
    }
    else {
        std::cout << "=== AVX-512: not supported, skipped ===\n\n";
    }
#endif

#if defined(__aarch64__)
    std::cout << "=== ARM64 NEON ===\n";
    bench_all_sizes(sm3::Impl::ARM64, "ARM64");
#endif

    // ����Ա�
    bench_comparison();

    std::cout << "============================================\n"
        << "  Benchmark complete\n"
        << "============================================\n";

    return 0;
}