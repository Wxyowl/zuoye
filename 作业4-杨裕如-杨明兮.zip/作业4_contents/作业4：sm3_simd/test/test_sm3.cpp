#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "../include/sm3.hpp"

static int g_pass = 0;
static int g_fail = 0;

// ------------------------------------------------------------------ //
// ���ߺ���
// ------------------------------------------------------------------ //

static std::string to_hex(const sm3::Digest& d)
{
    std::ostringstream oss;
    for (uint8_t b : d)
        oss << std::hex << std::setw(2) << std::setfill('0') << (int)b;
    return oss.str();
}

static sm3::Digest from_hex(const std::string& hex)
{
    sm3::Digest d{};
    for (int i = 0; i < 32; i++) {
        std::string byte_str = hex.substr(i * 2, 2);
        d[i] = static_cast<uint8_t>(std::stoul(byte_str, nullptr, 16));
    }
    return d;
}

static void check(const std::string& name,
    const sm3::Digest& got,
    const std::string& expected_hex)
{
    sm3::Digest expected = from_hex(expected_hex);
    if (got == expected) {
        std::cout << "[PASS] " << name << "\n";
        g_pass++;
    }
    else {
        std::cout << "[FAIL] " << name << "\n"
            << "       expected: " << expected_hex << "\n"
            << "       got:      " << to_hex(got) << "\n";
        g_fail++;
    }
}

// ------------------------------------------------------------------ //
// ��׼����������GB/T 32905-2016 ��¼A��
// ------------------------------------------------------------------ //

static constexpr char TV1_DIGEST[] =
"66c7f0f462eeedd9d1f2d46bdc10e4e24167c4875cf2f7a2297da02b8f4ba8e0";

static constexpr char TV2_DIGEST[] =
"debe9ff92275b8a138604889c18e5a4d6fdb70e5387e5765293dcba39c0c5732";

static constexpr char TV3_DIGEST[] =
"1ab21d8355cfa17f8e61194831e81a8f22bec8c728fefb747ed035eb5082aa2b";

// ------------------------------------------------------------------ //
// �Ե���ʵ�������в���
// ------------------------------------------------------------------ //

static void run_tests(sm3::Impl impl)
{
    std::string pre = std::string("[") +
        std::string(sm3::impl_name(impl)) + "] ";

    // --- TV1: "abc" ---
    {
        auto d = sm3::hash("abc", 3, impl);
        check(pre + "TV1: abc", d, TV1_DIGEST);
    }

    // --- TV2: 64�ֽ����� ---
    {
        const char* msg =
            "abcdabcdabcdabcdabcdabcdabcdabcd"
            "abcdabcdabcdabcdabcdabcdabcdabcd";
        auto d = sm3::hash(msg, 64, impl);
        check(pre + "TV2: 64-byte block", d, TV2_DIGEST);
    }

    // --- TV3: ����Ϣ ---
    {
        auto d = sm3::hash("", 0, impl);
        check(pre + "TV3: empty", d, TV3_DIGEST);
    }

    // --- TV4: ��ʽ�ֶ� a + b + c ---
    {
        sm3::Context ctx(impl);
        ctx.update("a", 1);
        ctx.update("b", 1);
        ctx.update("c", 1);
        auto d = ctx.final();
        check(pre + "TV4: streaming a+b+c", d, TV1_DIGEST);
    }

    // --- TV5: 65�ֽڿ��߽� ---
    {
        std::vector<uint8_t> msg(65, 0x61);
        auto d1 = sm3::hash(msg.data(), msg.size(), impl);
        auto d2 = sm3::hash(msg.data(), msg.size(), sm3::Impl::Ref);
        if (d1 == d2) {
            std::cout << "[PASS] " << pre << "TV5: 65-byte cross-block\n";
            g_pass++;
        }
        else {
            std::cout << "[FAIL] " << pre << "TV5: 65-byte cross-block\n"
                << "       ref: " << to_hex(d2) << "\n"
                << "       got: " << to_hex(d1) << "\n";
            g_fail++;
        }
    }

    // --- TV6: 1MB ��ʽ���� ---
    {
        constexpr std::size_t BIG = 1024 * 1024;
        std::vector<uint8_t> big(BIG, 0x61);

        // һ����
        auto d1 = sm3::hash(big.data(), BIG, impl);

        // ��ʽ��ÿ�� 1000 �ֽ�
        sm3::Context ctx(impl);
        std::size_t off = 0;
        while (off < BIG) {
            std::size_t chunk = (BIG - off < 1000) ? (BIG - off) : 1000;
            ctx.update(big.data() + off, chunk);
            off += chunk;
        }
        auto d2 = ctx.final();

        if (d1 == d2) {
            std::cout << "[PASS] " << pre << "TV6: 1MB streaming\n";
            g_pass++;
        }
        else {
            std::cout << "[FAIL] " << pre << "TV6: 1MB streaming\n"
                << "       oneshot:   " << to_hex(d1) << "\n"
                << "       streaming: " << to_hex(d2) << "\n";
            g_fail++;
        }
    }
}

// ------------------------------------------------------------------ //
// main
// ------------------------------------------------------------------ //

int main()
{
    std::cout << "============================================\n"
        << "  SM3 Correctness Test\n"
        << "  Best impl: " << sm3::impl_name(sm3::best_impl()) << "\n"
        << "============================================\n\n";

    // �ο�ʵ��
    run_tests(sm3::Impl::Ref);
    std::cout << "\n";

#if defined(__x86_64__) || defined(_M_X64)
    // AVX2
    run_tests(sm3::Impl::AVX2);
    std::cout << "\n";

    // AVX512
    if (sm3::best_impl() == sm3::Impl::AVX512) {
        run_tests(sm3::Impl::AVX512);
        std::cout << "\n";
    }
    else {
        std::cout << "[SKIP] AVX-512 not supported on this CPU\n\n";
    }
#endif

#if defined(__aarch64__)
    run_tests(sm3::Impl::ARM64);
    std::cout << "\n";
#endif

    std::cout << "============================================\n"
        << "  PASSED: " << g_pass << "\n"
        << "  FAILED: " << g_fail << "\n"
        << "============================================\n";

    return (g_fail == 0) ? 0 : 1;
}