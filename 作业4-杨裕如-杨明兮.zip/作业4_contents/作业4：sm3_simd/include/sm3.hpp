#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>

namespace sm3 {

    // ------------------------------------------------------------------ //
    // ����
    // ------------------------------------------------------------------ //

    inline constexpr std::size_t DIGEST_SIZE = 32;
    inline constexpr std::size_t BLOCK_SIZE = 64;

    using Digest = std::array<uint8_t, DIGEST_SIZE>;

    // ------------------------------------------------------------------ //
    // ʵ������
    // ------------------------------------------------------------------ //

    enum class Impl {
        Ref = 0,
        AVX2 = 1,
        AVX512 = 2,
        ARM64 = 3,
        Auto = 4,
    };

    std::string_view impl_name(Impl impl) noexcept;
    Impl             best_impl()          noexcept;
    void             set_impl(Impl impl)  noexcept;
    Impl             get_impl()           noexcept;

    // ------------------------------------------------------------------ //
    // ѹ����������
    // ------------------------------------------------------------------ //

    using CompressFn = void(*)(std::array<uint32_t, 8>&,
        const uint8_t*,
        std::size_t);

    void compress_ref(std::array<uint32_t, 8>& state,
        const uint8_t* data,
        std::size_t num_blocks);

#if defined(__x86_64__) || defined(_M_X64)
    void compress_avx2(std::array<uint32_t, 8>& state,
        const uint8_t* data,
        std::size_t num_blocks);
    void compress_avx512(std::array<uint32_t, 8>& state,
        const uint8_t* data,
        std::size_t num_blocks);
#endif

#if defined(__aarch64__)
    void compress_arm64(std::array<uint32_t, 8>& state,
        const uint8_t* data,
        std::size_t num_blocks);
#endif

    // ------------------------------------------------------------------ //
    // Context����ʽ��ϣ�ӿ�
    // ------------------------------------------------------------------ //

    class Context {
    public:
        explicit Context(Impl impl = Impl::Auto);

        void   reset();
        void   update(const void* data, std::size_t len);
        Digest final();

        // һ���Թ�ϣ
        static Digest hash(const void* data, std::size_t len,
            Impl impl = Impl::Auto);
        static Digest hash(std::string_view str,
            Impl impl = Impl::Auto);

    private:
        std::array<uint32_t, 8>         state_;
        uint64_t                        count_;
        std::array<uint8_t, BLOCK_SIZE> buf_;
        uint32_t                        buf_len_;
        CompressFn                      compress_;
    };

    // ------------------------------------------------------------------ //
    // ��ݺ���
    // ------------------------------------------------------------------ //

    inline Digest hash(const void* data, std::size_t len,
        Impl impl = Impl::Auto)
    {
        return Context::hash(data, len, impl);
    }

    inline Digest hash(std::string_view str, Impl impl = Impl::Auto)
    {
        return Context::hash(str, impl);
    }

    std::string to_hex(const Digest& digest);

} // namespace sm3